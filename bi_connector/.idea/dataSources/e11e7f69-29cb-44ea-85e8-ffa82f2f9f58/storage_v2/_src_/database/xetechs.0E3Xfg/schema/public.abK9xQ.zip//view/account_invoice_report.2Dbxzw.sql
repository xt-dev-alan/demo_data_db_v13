create view account_invoice_report
            (id, move_id, product_id, account_id, analytic_account_id, journal_id, company_id, currency_id,
             commercial_partner_id, name, state, type, partner_id, invoice_user_id, fiscal_position_id,
             invoice_payment_state, invoice_date, invoice_date_due, invoice_payment_term_id, invoice_partner_bank_id,
             residual, amount_total, product_uom_id, product_categ_id, quantity, price_subtotal, price_average,
             country_id, nbr_lines, team_id)
as
SELECT line.id,
       line.move_id,
       line.product_id,
       line.account_id,
       line.analytic_account_id,
       line.journal_id,
       line.company_id,
       line.currency_id,
       line.partner_id                                                                                       AS commercial_partner_id,
       move.name,
       move.state,
       move.type,
       move.partner_id,
       move.invoice_user_id,
       move.fiscal_position_id,
       move.invoice_payment_state,
       move.invoice_date,
       move.invoice_date_due,
       move.invoice_payment_term_id,
       move.invoice_partner_bank_id,
       move.amount_residual_signed                                                                           AS residual,
       move.amount_total_signed                                                                              AS amount_total,
       uom_template.id                                                                                       AS product_uom_id,
       template.categ_id                                                                                     AS product_categ_id,
       sum(line.quantity / NULLIF(COALESCE(uom_line.factor, 1::numeric) * COALESCE(uom_template.factor, 1::numeric),
                                  0.0))                                                                      AS quantity,
       - sum(line.balance)                                                                                   AS price_subtotal,
       - sum(line.balance / NULLIF(COALESCE(uom_line.factor, 1::numeric) * COALESCE(uom_template.factor, 1::numeric),
                                   0.0))                                                                     AS price_average,
       COALESCE(partner.country_id, commercial_partner.country_id)                                           AS country_id,
       1                                                                                                     AS nbr_lines,
       move.team_id
FROM account_move_line line
         LEFT JOIN res_partner partner ON partner.id = line.partner_id
         LEFT JOIN product_product product ON product.id = line.product_id
         LEFT JOIN account_account account ON account.id = line.account_id
         LEFT JOIN account_account_type user_type ON user_type.id = account.user_type_id
         LEFT JOIN product_template template ON template.id = product.product_tmpl_id
         LEFT JOIN uom_uom uom_line ON uom_line.id = line.product_uom_id
         LEFT JOIN uom_uom uom_template ON uom_template.id = template.uom_id
         JOIN account_move move ON move.id = line.move_id
         LEFT JOIN res_partner commercial_partner ON commercial_partner.id = move.commercial_partner_id
WHERE (move.type::text = ANY
       (ARRAY ['out_invoice'::character varying::text, 'out_refund'::character varying::text, 'in_invoice'::character varying::text, 'in_refund'::character varying::text, 'out_receipt'::character varying::text, 'in_receipt'::character varying::text]))
  AND line.account_id IS NOT NULL
  AND NOT line.exclude_from_invoice_tab
GROUP BY line.id, line.move_id, line.product_id, line.account_id, line.analytic_account_id, line.journal_id,
         line.company_id, line.currency_id, line.partner_id, move.name, move.state, move.type,
         move.amount_residual_signed, move.amount_total_signed, move.partner_id, move.invoice_user_id,
         move.fiscal_position_id, move.invoice_payment_state, move.invoice_date, move.invoice_date_due,
         move.invoice_payment_term_id, move.invoice_partner_bank_id, uom_template.id, template.categ_id,
         (COALESCE(partner.country_id, commercial_partner.country_id)), move.team_id;

alter table account_invoice_report
    owner to odoo;

