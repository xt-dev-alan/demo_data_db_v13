create view hr_employee_public
            (create_date, name, active, department_id, job_id, job_title, company_id, address_id, mobile_phone,
             work_phone, work_email, work_location, user_id, resource_id, resource_calendar_id, color, parent_id,
             coach_id, expense_manager_id, last_attendance_id, leave_manager_id, email_sent, ip_connected,
             manually_set_present, hr_presence_state_display, last_check_in, last_check_out, id, create_uid, write_uid,
             write_date, timesheet_manager_id)
as
SELECT emp.create_date,
       emp.name,
       emp.active,
       emp.department_id,
       emp.job_id,
       emp.job_title,
       emp.company_id,
       emp.address_id,
       emp.mobile_phone,
       emp.work_phone,
       emp.work_email,
       emp.work_location,
       emp.user_id,
       emp.resource_id,
       emp.resource_calendar_id,
       emp.color,
       emp.parent_id,
       emp.coach_id,
       emp.expense_manager_id,
       emp.last_attendance_id,
       emp.leave_manager_id,
       emp.email_sent,
       emp.ip_connected,
       emp.manually_set_present,
       emp.hr_presence_state_display,
       emp.last_check_in,
       emp.last_check_out,
       emp.id,
       emp.create_uid,
       emp.write_uid,
       emp.write_date,
       emp.timesheet_manager_id
FROM hr_employee emp;

alter table hr_employee_public
    owner to odoo;

