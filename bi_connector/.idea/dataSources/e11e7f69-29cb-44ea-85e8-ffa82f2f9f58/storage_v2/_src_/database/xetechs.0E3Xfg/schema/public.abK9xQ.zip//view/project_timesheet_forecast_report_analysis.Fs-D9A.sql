create view project_timesheet_forecast_report_analysis
            (entry_date, employee_id, task_id, project_id, number_hours, line_type, id) as
SELECT d.d::date                                                             AS entry_date,
       f.employee_id,
       f.task_id,
       f.project_id,
       f.allocated_hours / NULLIF(f.working_days_count, 0)::double precision AS number_hours,
       'forecast'::text                                                      AS line_type,
       f.id
FROM generate_series(((SELECT min(planning_slot.start_datetime) AS min
                       FROM planning_slot))::date::timestamp with time zone,
                     ((SELECT max(planning_slot.end_datetime) AS max
                       FROM planning_slot))::date::timestamp with time zone, '1 day'::interval) d(d)
         LEFT JOIN planning_slot f ON date(d.d) >= f.start_datetime AND date(d.d) <= f.end_datetime
         LEFT JOIN hr_employee e ON f.employee_id = e.id
         LEFT JOIN resource_resource r ON e.resource_id = r.id
WHERE (date_part('isodow'::text, date(d.d)) IN (SELECT a.dayofweek::integer + 1
                                                FROM resource_calendar_attendance a
                                                WHERE a.calendar_id = r.calendar_id))
UNION
SELECT a.date            AS entry_date,
       e.id              AS employee_id,
       a.task_id,
       a.project_id,
       a.unit_amount     AS number_hours,
       'timesheet'::text AS line_type,
       - a.id            AS id
FROM account_analytic_line a,
     hr_employee e
WHERE a.project_id IS NOT NULL
  AND a.employee_id = e.id;

alter table project_timesheet_forecast_report_analysis
    owner to odoo;

