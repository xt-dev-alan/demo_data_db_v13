create view project_profitability_report
            (id, project_id, user_id, sale_line_id, analytic_account_id, partner_id, company_id, currency_id,
             sale_order_id, order_confirmation_date, product_id, sale_qty_delivered_method,
             expense_amount_untaxed_to_invoice, expense_amount_untaxed_invoiced, amount_untaxed_to_invoice,
             amount_untaxed_invoiced, timesheet_unit_amount, timesheet_cost, expense_cost)
as
SELECT row_number() OVER (ORDER BY p.id, sol.id) AS id,
       p.id                                      AS project_id,
       p.user_id,
       sol.id                                    AS sale_line_id,
       p.analytic_account_id,
       p.partner_id,
       c.id                                      AS company_id,
       c.currency_id,
       s.id                                      AS sale_order_id,
       s.date_order                              AS order_confirmation_date,
       sol.product_id,
       sol.qty_delivered_method                  AS sale_qty_delivered_method,
       CASE
           WHEN sol.qty_delivered_method::text = 'analytic'::text THEN sol.untaxed_amount_to_invoice /
                                                                       CASE COALESCE(s.currency_rate, 0::numeric)
                                                                           WHEN 0 THEN 1.0
                                                                           ELSE s.currency_rate
                                                                           END
           ELSE 0.0
           END                                   AS expense_amount_untaxed_to_invoice,
       CASE
           WHEN sol.qty_delivered_method::text = 'analytic'::text AND sol.invoice_status::text <> 'no'::text THEN
               CASE
                   WHEN t.expense_policy::text = 'sales_price'::text THEN sol.price_reduce /
                                                                          CASE COALESCE(s.currency_rate, 0::numeric)
                                                                              WHEN 0 THEN 1.0
                                                                              ELSE s.currency_rate
                                                                              END * sol.qty_invoiced
                   ELSE - cost_summary.expense_cost
                   END
           ELSE 0.0
           END                                   AS expense_amount_untaxed_invoiced,
       CASE
           WHEN sol.qty_delivered_method::text = ANY
                (ARRAY ['timesheet'::character varying::text, 'manual'::character varying::text, 'stock_move'::character varying::text])
               THEN sol.untaxed_amount_to_invoice /
                    CASE COALESCE(s.currency_rate, 0::numeric)
                        WHEN 0 THEN 1.0
                        ELSE s.currency_rate
                        END
           ELSE 0.0
           END                                   AS amount_untaxed_to_invoice,
       CASE
           WHEN sol.qty_delivered_method::text = ANY
                (ARRAY ['timesheet'::character varying::text, 'manual'::character varying::text, 'stock_move'::character varying::text])
               THEN COALESCE(sol.untaxed_amount_invoiced, cost_summary.downpayment_invoiced) /
                    CASE COALESCE(s.currency_rate, 0::numeric)
                        WHEN 0 THEN 1.0
                        ELSE s.currency_rate
                        END
           ELSE 0.0
           END                                   AS amount_untaxed_invoiced,
       cost_summary.timesheet_unit_amount,
       cost_summary.timesheet_cost,
       cost_summary.expense_cost
FROM project_project p
         JOIN res_company c ON c.id = p.company_id
         LEFT JOIN (SELECT sub_cost_summary.project_id,
                           sub_cost_summary.analytic_account_id,
                           sub_cost_summary.sale_line_id,
                           sum(sub_cost_summary.timesheet_unit_amount) AS timesheet_unit_amount,
                           sum(sub_cost_summary.timesheet_cost)        AS timesheet_cost,
                           sum(sub_cost_summary.expense_cost)          AS expense_cost,
                           sum(sub_cost_summary.downpayment_invoiced)  AS downpayment_invoiced
                    FROM (SELECT p_1.id              AS project_id,
                                 p_1.analytic_account_id,
                                 ts.so_line          AS sale_line_id,
                                 sum(ts.unit_amount) AS timesheet_unit_amount,
                                 sum(ts.amount)      AS timesheet_cost,
                                 0.0                 AS expense_cost,
                                 0.0                 AS downpayment_invoiced
                          FROM account_analytic_line ts,
                               project_project p_1
                          WHERE ts.project_id IS NOT NULL
                            AND p_1.id = ts.project_id
                            AND p_1.active = true
                            AND p_1.allow_timesheets = true
                          GROUP BY p_1.id, ts.so_line
                          UNION
                          SELECT p_1.id      AS project_id,
                                 p_1.analytic_account_id,
                                 aal.so_line AS sale_line_id,
                                 0.0         AS timesheet_unit_amount,
                                 0.0         AS timesheet_cost,
                                 CASE
                                     WHEN aal.product_id <> COALESCE((SELECT ir_config_parameter.value
                                                                      FROM ir_config_parameter
                                                                      WHERE ir_config_parameter.key::text =
                                                                            'sale.default_deposit_product_id'::text),
                                                                     '-1'::text)::integer THEN sum(aal.amount)
                                     ELSE 0.0
                                     END     AS expense_cost,
                                 0.0         AS downpayment_invoiced
                          FROM project_project p_1
                                   LEFT JOIN account_analytic_account aa ON p_1.analytic_account_id = aa.id
                                   LEFT JOIN account_analytic_line aal ON aal.account_id = aa.id
                          WHERE aal.amount < 0.0
                            AND aal.project_id IS NULL
                            AND p_1.active = true
                            AND p_1.allow_timesheets = true
                          GROUP BY p_1.id, aa.id, aal.so_line, aal.product_id
                          UNION
                          SELECT p_1.id     AS project_id,
                                 p_1.analytic_account_id,
                                 my_sols.id AS sale_line_id,
                                 0.0        AS timesheet_unit_amount,
                                 0.0        AS timesheet_cost,
                                 0.0        AS expense_cost,
                                 CASE
                                     WHEN my_sols.invoice_status::text = 'invoiced'::text THEN my_sols.price_reduce
                                     ELSE 0.0
                                     END    AS downpayment_invoiced
                          FROM project_project p_1
                                   LEFT JOIN sale_order_line my_sol ON p_1.sale_line_id = my_sol.id
                                   LEFT JOIN sale_order my_s ON my_sol.order_id = my_s.id
                                   LEFT JOIN sale_order_line my_sols ON my_sols.order_id = my_s.id
                          WHERE my_sols.is_downpayment = true
                          GROUP BY p_1.id, my_sols.id
                          UNION
                          SELECT p_1.id            AS project_id,
                                 p_1.analytic_account_id,
                                 olis.id           AS sale_line_id,
                                 0.0               AS timesheet_unit_amount,
                                 0.0               AS timesheet_cost,
                                 olis.price_reduce AS expense_cost,
                                 0.0               AS downpayment_invoiced
                          FROM project_project p_1
                                   LEFT JOIN account_analytic_account anac ON p_1.analytic_account_id = anac.id
                                   LEFT JOIN account_analytic_line anli ON anac.id = anli.account_id
                                   LEFT JOIN sale_order_line oli ON p_1.sale_line_id = oli.id
                                   LEFT JOIN sale_order ord ON oli.order_id = ord.id
                                   LEFT JOIN sale_order_line olis ON ord.id = olis.order_id
                          WHERE olis.product_id = anli.product_id
                            AND olis.is_downpayment = true
                            AND anli.amount < 0.0
                            AND anli.project_id IS NULL
                            AND p_1.active = true
                            AND p_1.allow_timesheets = true
                          GROUP BY p_1.id, olis.id
                          UNION
                          SELECT p_1.id   AS project_id,
                                 p_1.analytic_account_id,
                                 sol_1.id AS sale_line_id,
                                 0.0      AS timesheet_unit_amount,
                                 0.0      AS timesheet_cost,
                                 0.0      AS expense_cost,
                                 0.0      AS downpayment_invoiced
                          FROM sale_order_line sol_1
                                   JOIN project_project p_1 ON sol_1.project_id = p_1.id
                          WHERE p_1.active = true
                            AND p_1.allow_timesheets = true
                          UNION
                          SELECT p_1.id   AS project_id,
                                 p_1.analytic_account_id,
                                 sol_1.id AS sale_line_id,
                                 0.0      AS timesheet_unit_amount,
                                 0.0      AS timesheet_cost,
                                 0.0      AS expense_cost,
                                 0.0      AS downpayment_invoiced
                          FROM sale_order_line sol_1
                                   JOIN project_task t_1 ON sol_1.task_id = t_1.id
                                   JOIN project_project p_1 ON p_1.id = t_1.project_id
                          WHERE p_1.active = true
                            AND p_1.allow_timesheets = true) sub_cost_summary
                    GROUP BY sub_cost_summary.project_id, sub_cost_summary.analytic_account_id,
                             sub_cost_summary.sale_line_id) cost_summary ON cost_summary.project_id = p.id
         LEFT JOIN sale_order_line sol ON cost_summary.sale_line_id = sol.id
         LEFT JOIN sale_order s ON sol.order_id = s.id
         LEFT JOIN product_product pp ON sol.product_id = pp.id
         LEFT JOIN product_template t ON pp.product_tmpl_id = t.id
WHERE p.active = true
  AND p.analytic_account_id IS NOT NULL;

alter table project_profitability_report
    owner to odoo;

