create view purchase_bill_union
            (id, name, reference, partner_id, date, amount, currency_id, company_id, vendor_bill_id,
             purchase_order_id) as
SELECT account_move.id,
       account_move.name,
       account_move.ref            AS reference,
       account_move.partner_id,
       account_move.date,
       account_move.amount_untaxed AS amount,
       account_move.currency_id,
       account_move.company_id,
       account_move.id             AS vendor_bill_id,
       NULL::integer               AS purchase_order_id
FROM account_move
WHERE account_move.type::text = 'in_invoice'::text
  AND account_move.state::text = 'posted'::text
UNION
SELECT - purchase_order.id             AS id,
       purchase_order.name,
       purchase_order.partner_ref      AS reference,
       purchase_order.partner_id,
       purchase_order.date_order::date AS date,
       purchase_order.amount_untaxed   AS amount,
       purchase_order.currency_id,
       purchase_order.company_id,
       NULL::integer                   AS vendor_bill_id,
       purchase_order.id               AS purchase_order_id
FROM purchase_order
WHERE (purchase_order.state::text = ANY (ARRAY ['purchase'::character varying::text, 'done'::character varying::text]))
  AND (purchase_order.invoice_status::text = ANY
       (ARRAY ['to invoice'::character varying::text, 'no'::character varying::text]));

alter table purchase_bill_union
    owner to odoo;

