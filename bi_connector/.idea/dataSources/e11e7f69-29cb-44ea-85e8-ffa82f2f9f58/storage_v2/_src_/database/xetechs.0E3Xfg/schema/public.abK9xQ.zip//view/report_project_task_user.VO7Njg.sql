create view report_project_task_user
            (nbr, id, date_assign, date_end, date_last_stage_update, date_deadline, user_id, project_id, priority, name,
             company_id, partner_id, stage_id, state, working_days_close, working_days_open, delay_endings_days,
             progress, hours_effective, remaining_hours, hours_planned, planned_date_begin, planned_date_end)
as
SELECT (SELECT 1)                                                      AS nbr,
       t.id,
       t.date_assign,
       t.date_end,
       t.date_last_stage_update,
       t.date_deadline,
       t.user_id,
       t.project_id,
       t.priority,
       t.name,
       t.company_id,
       t.partner_id,
       t.stage_id,
       t.kanban_state                                                  AS state,
       t.working_days_close,
       t.working_days_open,
       date_part('epoch'::text, t.date_deadline::timestamp without time zone - timezone('UTC'::text, now())) /
       (3600 * 24)::double precision                                   AS delay_endings_days,
       t.progress,
       t.effective_hours                                               AS hours_effective,
       t.planned_hours - t.effective_hours - t.subtask_effective_hours AS remaining_hours,
       t.planned_hours                                                 AS hours_planned,
       t.planned_date_begin,
       t.planned_date_end
FROM project_task t
WHERE t.active = true
GROUP BY t.id, t.create_date, t.write_date, t.date_assign, t.date_end, t.date_deadline, t.date_last_stage_update,
         t.user_id, t.project_id, t.priority, t.name, t.company_id, t.partner_id, t.stage_id, t.remaining_hours,
         t.effective_hours, t.progress, t.planned_hours, t.planned_date_begin, t.planned_date_end;

alter table report_project_task_user
    owner to odoo;

