create view hr_referral_report
            (id, applicant_id, write_date, earned_points, points_not_hired, referral_state, ref_user_id, job_id,
             department_id, medium_id, employee_referral_hired, employee_referral_refused)
as
SELECT a.id,
       a.id         AS applicant_id,
       a.write_date,
       point.points AS earned_points,
       points_not_hired.points_not_hired,
       a.referral_state,
       a.ref_user_id,
       a.job_id,
       a.department_id,
       m.id         AS medium_id,
       CASE
           WHEN a.referral_state::text = 'hired'::text THEN 1
           ELSE 0
           END      AS employee_referral_hired,
       CASE
           WHEN a.referral_state::text = 'closed'::text THEN 1
           ELSE 0
           END      AS employee_referral_refused
FROM hr_applicant a
         LEFT JOIN (SELECT hr_referral_points.applicant_id,
                           sum(hr_referral_points.points) AS points
                    FROM hr_referral_points
                    GROUP BY hr_referral_points.applicant_id) point ON a.id = point.applicant_id
         LEFT JOIN (SELECT hr_referral_points.applicant_id,
                           sum(hr_referral_points.points) AS points_not_hired
                    FROM hr_referral_points
                    GROUP BY hr_referral_points.applicant_id) points_not_hired
                   ON a.id = points_not_hired.applicant_id AND a.referral_state::text = 'closed'::text
         JOIN utm_medium m ON a.medium_id = m.id;

alter table hr_referral_report
    owner to odoo;

