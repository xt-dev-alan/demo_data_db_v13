create view sale_subscription_report
            (id, name, product_id, product_uom, analytic_account_id, recurring_monthly, recurring_yearly,
             recurring_total, quantity, date_start, date_end, partner_id, user_id, team_id, company_id, to_renew,
             in_progress, health, stage_id, template_id, categ_id, pricelist_id, product_tmpl_id, country_id,
             commercial_partner_id, industry_id, close_reason_id)
as
SELECT min(l.id)                                                                         AS id,
       sub.name,
       l.product_id,
       l.uom_id                                                                          AS product_uom,
       sub.analytic_account_id,
       sum(COALESCE(l.price_subtotal::double precision / NULLIF(sub.recurring_total, 0::double precision),
                    0::double precision) * sub.recurring_monthly)                        AS recurring_monthly,
       sum(COALESCE(l.price_subtotal::double precision / NULLIF(sub.recurring_total, 0::double precision),
                    0::double precision) * sub.recurring_monthly * 12::double precision) AS recurring_yearly,
       sum(l.price_subtotal)                                                             AS recurring_total,
       sum(l.quantity)                                                                   AS quantity,
       sub.date_start,
       sub.date                                                                          AS date_end,
       sub.partner_id,
       sub.user_id,
       sub.team_id,
       sub.company_id,
       sub.to_renew,
       stage.in_progress,
       sub.health,
       sub.stage_id,
       sub.template_id,
       t.categ_id,
       sub.pricelist_id,
       p.product_tmpl_id,
       partner.country_id,
       partner.commercial_partner_id,
       partner.industry_id,
       sub.close_reason_id
FROM sale_subscription_line l
         JOIN sale_subscription sub ON l.analytic_account_id = sub.id
         JOIN sale_subscription_stage stage ON sub.stage_id = stage.id
         LEFT JOIN account_analytic_account a ON sub.analytic_account_id = a.id
         JOIN res_partner partner ON sub.partner_id = partner.id
         LEFT JOIN product_product p ON l.product_id = p.id
         LEFT JOIN product_template t ON p.product_tmpl_id = t.id
         LEFT JOIN uom_uom u ON u.id = l.uom_id
GROUP BY l.product_id, l.uom_id, t.categ_id, sub.analytic_account_id, sub.recurring_monthly, sub.recurring_total,
         sub.date_start, sub.date, sub.partner_id, sub.user_id, sub.team_id, l.quantity, sub.company_id, sub.to_renew,
         stage.in_progress, sub.health, sub.stage_id, sub.name, sub.template_id, sub.pricelist_id, p.product_tmpl_id,
         partner.country_id, partner.commercial_partner_id, partner.industry_id, sub.close_reason_id;

alter table sale_subscription_report
    owner to odoo;

