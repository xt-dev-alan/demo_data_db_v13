create view hr_leave_report
            (id, employee_id, name, number_of_days, leave_type, category_id, department_id, holiday_status_id, state,
             holiday_type, date_from, date_to, payslip_status)
as
SELECT row_number() OVER (ORDER BY leaves.employee_id) AS id,
       leaves.employee_id,
       leaves.name,
       leaves.number_of_days,
       leaves.leave_type,
       leaves.category_id,
       leaves.department_id,
       leaves.holiday_status_id,
       leaves.state,
       leaves.holiday_type,
       leaves.date_from,
       leaves.date_to,
       leaves.payslip_status
FROM (SELECT allocation.employee_id,
             allocation.name,
             allocation.number_of_days,
             allocation.category_id,
             allocation.department_id,
             allocation.holiday_status_id,
             allocation.state,
             allocation.holiday_type,
             NULL::timestamp without time zone AS date_from,
             NULL::timestamp without time zone AS date_to,
             false                             AS payslip_status,
             'allocation'::text                AS leave_type
      FROM hr_leave_allocation allocation
      UNION ALL
      SELECT request.employee_id,
             request.name,
             request.number_of_days * '-1'::integer::double precision AS number_of_days,
             request.category_id,
             request.department_id,
             request.holiday_status_id,
             request.state,
             request.holiday_type,
             request.date_from,
             request.date_to,
             request.payslip_status,
             'request'::text                                          AS leave_type
      FROM hr_leave request) leaves;

alter table hr_leave_report
    owner to odoo;

