create view stock_report
            (id, picking_name, date_done, creation_date, scheduled_date, partner_id, is_backorder, delay, is_late,
             cycle_time, picking_type_code, operation_type, product_id, reference, picking_id, inventory_id, state,
             product_qty, company_id, categ_id)
as
SELECT sm.id,
       sp.name                        AS picking_name,
       sp.date_done,
       sp.creation_date,
       sp.scheduled_date,
       sp.partner_id,
       sp.is_backorder,
       sp.delay,
       sp.delay > 0::double precision AS is_late,
       sp.cycle_time,
       spt.code                       AS picking_type_code,
       spt.name                       AS operation_type,
       p.id                           AS product_id,
       sm.reference,
       sm.picking_id,
       sm.inventory_id,
       sm.state,
       sm.product_qty,
       sm.company_id,
       cat.id                         AS categ_id
FROM stock_move sm
         LEFT JOIN (SELECT stock_picking.id,
                           stock_picking.name,
                           stock_picking.date_done,
                           stock_picking.date                               AS creation_date,
                           stock_picking.scheduled_date,
                           stock_picking.partner_id,
                           stock_picking.backorder_id IS NOT NULL           AS is_backorder,
                           date_part('epoch'::text, avg(date_trunc('day'::text, stock_picking.date_done) -
                                                        date_trunc('day'::text, stock_picking.scheduled_date))) /
                           (24 * 60 * 60)::numeric(16, 2)::double precision AS delay,
                           date_part('epoch'::text, avg(date_trunc('day'::text, stock_picking.date_done) -
                                                        date_trunc('day'::text, stock_picking.date))) /
                           (24 * 60 * 60)::numeric(16, 2)::double precision AS cycle_time
                    FROM stock_picking
                    GROUP BY stock_picking.id, stock_picking.name, stock_picking.date_done, stock_picking.date,
                             stock_picking.scheduled_date, stock_picking.partner_id,
                             (stock_picking.backorder_id IS NOT NULL)) sp ON sm.picking_id = sp.id
         LEFT JOIN stock_picking_type spt ON sm.picking_type_id = spt.id
         JOIN product_product p ON sm.product_id = p.id
         JOIN product_template t ON p.product_tmpl_id = t.id
         JOIN product_category cat ON t.categ_id = cat.id
GROUP BY sm.id, sm.reference, sm.picking_id, sm.inventory_id, sm.state, sm.product_qty, sm.company_id, sp.name,
         sp.date_done, sp.creation_date, sp.scheduled_date, sp.partner_id, sp.is_backorder, sp.delay, sp.cycle_time,
         spt.code, spt.name, p.id, (sp.delay > 0::double precision), cat.id;

alter table stock_report
    owner to odoo;

