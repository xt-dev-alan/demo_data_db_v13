create view im_livechat_report_channel
            (id, uuid, channel_id, channel_name, technical_name, livechat_channel_id, start_date, start_date_hour,
             start_hour, day_number, duration, time_to_answer, nbr_speaker, nbr_message, is_without_answer,
             days_of_activity, is_anonymous, country_id, is_happy, rating, rating_text, is_unrated, partner_id)
as
SELECT c.id,
       c.uuid,
       c.id                                                                            AS channel_id,
       c.name                                                                          AS channel_name,
       concat(l.name, ' / ', c.id)                                                     AS technical_name,
       c.livechat_channel_id,
       c.create_date                                                                   AS start_date,
       to_char(date_trunc('hour'::text, c.create_date), 'YYYY-MM-DD HH24:MI:SS'::text) AS start_date_hour,
       to_char(date_trunc('hour'::text, c.create_date), 'HH24'::text)                  AS start_hour,
       date_part('dow'::text, c.create_date)                                           AS day_number,
       date_part('epoch'::text, max(m.create_date) - min(m.create_date))               AS duration,
       date_part('epoch'::text, min(mo.create_date) - min(m.create_date))              AS time_to_answer,
       count(DISTINCT c.livechat_operator_id)                                          AS nbr_speaker,
       count(DISTINCT m.id)                                                            AS nbr_message,
       CASE
           WHEN (EXISTS(SELECT DISTINCT m_1.author_id
                        FROM mail_message m_1,
                             mail_message_mail_channel_rel r_1
                        WHERE m_1.author_id = c.livechat_operator_id
                          AND r_1.mail_channel_id = c.id
                          AND r_1.mail_message_id = m_1.id
                          AND c.livechat_operator_id = m_1.author_id)) THEN 0
           ELSE 1
           END                                                                         AS is_without_answer,
       date_part('day'::text,
                 date_trunc('day'::text, now()) - date_trunc('day'::text, c.create_date)::timestamp with time zone) +
       1::double precision                                                             AS days_of_activity,
       CASE
           WHEN c.anonymous_name IS NULL THEN 0
           ELSE 1
           END                                                                         AS is_anonymous,
       c.country_id,
       CASE
           WHEN rate.rating = 10::double precision THEN 1
           ELSE 0
           END                                                                         AS is_happy,
       rate.rating,
       CASE
           WHEN rate.rating = 1::double precision THEN 'Unhappy'::text
           WHEN rate.rating = 10::double precision THEN 'Happy'::text
           WHEN rate.rating = 5::double precision THEN 'Neutral'::text
           ELSE NULL::text
           END                                                                         AS rating_text,
       CASE
           WHEN rate.rating > 0::double precision THEN 0
           ELSE 1
           END                                                                         AS is_unrated,
       c.livechat_operator_id                                                          AS partner_id
FROM mail_channel c
         JOIN mail_message_mail_channel_rel r ON c.id = r.mail_channel_id
         JOIN mail_message m ON m.id = r.mail_message_id
         JOIN im_livechat_channel l ON l.id = c.livechat_channel_id
         LEFT JOIN mail_message mo ON r.mail_message_id = mo.id AND mo.author_id = c.livechat_operator_id
         LEFT JOIN rating_rating rate ON rate.res_id = c.id AND rate.res_model::text = 'mail.channel'::text AND
                                         rate.parent_res_model::text = 'im_livechat.channel'::text
WHERE c.livechat_operator_id IS NOT NULL
GROUP BY c.livechat_operator_id, c.id, c.name, c.livechat_channel_id, l.name, c.create_date, c.uuid, rate.rating;

alter table im_livechat_report_channel
    owner to odoo;

