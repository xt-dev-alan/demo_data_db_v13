create view report_stock_quantity(id, product_id, state, date, product_qty, company_id, warehouse_id) as
SELECT m.id,
       m.product_id,
       CASE
           WHEN (ls.usage::text = 'internal'::text OR
                 ls.usage::text = 'transit'::text AND ls.company_id IS NOT NULL) AND ld.usage::text <> 'internal'::text
               THEN 'out'::text
           WHEN ls.usage::text <> 'internal'::text AND
                (ld.usage::text = 'internal'::text OR ld.usage::text = 'transit'::text AND ld.company_id IS NOT NULL)
               THEN 'in'::text
           ELSE NULL::text
           END               AS state,
       m.date_expected::date AS date,
       CASE
           WHEN (ls.usage::text = 'internal'::text OR
                 ls.usage::text = 'transit'::text AND ls.company_id IS NOT NULL) AND ld.usage::text <> 'internal'::text
               THEN - m.product_qty
           WHEN ls.usage::text <> 'internal'::text AND
                (ld.usage::text = 'internal'::text OR ld.usage::text = 'transit'::text AND ld.company_id IS NOT NULL)
               THEN m.product_qty
           ELSE NULL::numeric
           END               AS product_qty,
       m.company_id,
       CASE
           WHEN (ls.usage::text = 'internal'::text OR
                 ls.usage::text = 'transit'::text AND ls.company_id IS NOT NULL) AND ld.usage::text <> 'internal'::text
               THEN whs.id
           WHEN ls.usage::text <> 'internal'::text AND
                (ld.usage::text = 'internal'::text OR ld.usage::text = 'transit'::text AND ld.company_id IS NOT NULL)
               THEN whd.id
           ELSE NULL::integer
           END               AS warehouse_id
FROM stock_move m
         LEFT JOIN stock_location ls ON ls.id = m.location_id
         LEFT JOIN stock_location ld ON ld.id = m.location_dest_id
         LEFT JOIN stock_warehouse whs ON ls.parent_path::text ~~ concat('%/', whs.view_location_id, '/%')
         LEFT JOIN stock_warehouse whd ON ld.parent_path::text ~~ concat('%/', whd.view_location_id, '/%')
         LEFT JOIN product_product pp ON pp.id = m.product_id
         LEFT JOIN product_template pt ON pt.id = pp.product_tmpl_id
WHERE pt.type::text = 'product'::text
  AND m.product_qty <> 0::numeric
  AND ((ls.usage::text = 'internal'::text OR ls.usage::text = 'transit'::text AND ls.company_id IS NOT NULL) AND
       ld.usage::text <> 'internal'::text OR ls.usage::text <> 'internal'::text AND
                                             (ld.usage::text = 'internal'::text OR
                                              ld.usage::text = 'transit'::text AND ld.company_id IS NOT NULL))
  AND (m.state::text <> ALL
       (ARRAY ['cancel'::character varying::text, 'draft'::character varying::text, 'done'::character varying::text]))
UNION
SELECT - q.id           AS id,
       q.product_id,
       'forecast'::text AS state,
       date.date::date  AS date,
       q.quantity       AS product_qty,
       q.company_id,
       wh.id            AS warehouse_id
FROM generate_series(timezone('utc'::text, now())::date - '3 mons'::interval,
                     timezone('utc'::text, now())::date + '3 mons'::interval, '1 day'::interval) date(date),
     stock_quant q
         LEFT JOIN stock_location l ON l.id = q.location_id
         LEFT JOIN stock_warehouse wh ON l.parent_path::text ~~ concat('%/', wh.view_location_id, '/%')
WHERE l.usage::text = 'internal'::text
UNION
SELECT m.id,
       m.product_id,
       'forecast'::text                          AS state,
       generate_series(
               CASE
                   WHEN m.state::text = 'done'::text THEN timezone('utc'::text, now())::date - '3 mons'::interval
                   ELSE m.date_expected::date::timestamp without time zone
                   END,
               CASE
                   WHEN m.state::text <> 'done'::text THEN timezone('utc'::text, now())::date + '3 mons'::interval
                   ELSE m.date::date - '1 day'::interval
                   END, '1 day'::interval)::date AS date,
       CASE
           WHEN (ls.usage::text = 'internal'::text OR
                 ls.usage::text = 'transit'::text AND ls.company_id IS NOT NULL) AND
                ld.usage::text <> 'internal'::text AND m.state::text = 'done'::text THEN m.product_qty
           WHEN ls.usage::text <> 'internal'::text AND (ld.usage::text = 'internal'::text OR
                                                        ld.usage::text = 'transit'::text AND ld.company_id IS NOT NULL) AND
                m.state::text = 'done'::text THEN - m.product_qty
           WHEN (ls.usage::text = 'internal'::text OR
                 ls.usage::text = 'transit'::text AND ls.company_id IS NOT NULL) AND ld.usage::text <> 'internal'::text
               THEN - m.product_qty
           WHEN ls.usage::text <> 'internal'::text AND
                (ld.usage::text = 'internal'::text OR ld.usage::text = 'transit'::text AND ld.company_id IS NOT NULL)
               THEN m.product_qty
           ELSE NULL::numeric
           END                                   AS product_qty,
       m.company_id,
       CASE
           WHEN (ls.usage::text = 'internal'::text OR
                 ls.usage::text = 'transit'::text AND ls.company_id IS NOT NULL) AND ld.usage::text <> 'internal'::text
               THEN whs.id
           WHEN ls.usage::text <> 'internal'::text AND
                (ld.usage::text = 'internal'::text OR ld.usage::text = 'transit'::text AND ld.company_id IS NOT NULL)
               THEN whd.id
           ELSE NULL::integer
           END                                   AS warehouse_id
FROM stock_move m
         LEFT JOIN stock_location ls ON ls.id = m.location_id
         LEFT JOIN stock_location ld ON ld.id = m.location_dest_id
         LEFT JOIN stock_warehouse whs ON ls.parent_path::text ~~ concat('%/', whs.view_location_id, '/%')
         LEFT JOIN stock_warehouse whd ON ld.parent_path::text ~~ concat('%/', whd.view_location_id, '/%')
         LEFT JOIN product_product pp ON pp.id = m.product_id
         LEFT JOIN product_template pt ON pt.id = pp.product_tmpl_id
WHERE pt.type::text = 'product'::text
  AND m.product_qty <> 0::numeric
  AND ((ls.usage::text = 'internal'::text OR ls.usage::text = 'transit'::text AND ls.company_id IS NOT NULL) AND
       ld.usage::text <> 'internal'::text OR ls.usage::text <> 'internal'::text AND
                                             (ld.usage::text = 'internal'::text OR
                                              ld.usage::text = 'transit'::text AND ld.company_id IS NOT NULL))
  AND (m.state::text <> ALL (ARRAY ['cancel'::character varying::text, 'draft'::character varying::text]));

alter table report_stock_quantity
    owner to odoo;

