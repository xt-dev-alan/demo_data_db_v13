create view planning_slot_report_analysis(id, entry_date, role_id, company_id, employee_id, number_hours) as
SELECT p.id,
       generate_series(p.start_datetime, p.end_datetime, '1 day'::interval)                      AS entry_date,
       p.role_id,
       p.company_id,
       p.employee_id,
       p.allocated_hours / (p.end_datetime::date - p.start_datetime::date + 1)::double precision AS number_hours
FROM planning_slot p;

alter table planning_slot_report_analysis
    owner to odoo;

