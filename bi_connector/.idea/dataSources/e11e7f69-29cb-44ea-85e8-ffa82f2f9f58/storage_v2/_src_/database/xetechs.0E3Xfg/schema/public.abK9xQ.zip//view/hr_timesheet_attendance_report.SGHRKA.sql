create view hr_timesheet_attendance_report (id, user_id, date, total_attendance, total_timesheet, total_difference) as
SELECT max(t.id)                                                                                          AS id,
       t.user_id,
       t.date,
       COALESCE(sum(t.attendance), 0::double precision)                                                   AS total_attendance,
       COALESCE(sum(t.timesheet), 0::double precision)                                                    AS total_timesheet,
       COALESCE(sum(t.attendance), 0::double precision) -
       COALESCE(sum(t.timesheet), 0::double precision)                                                    AS total_difference
FROM (SELECT - hr_attendance.id           AS id,
             resource_resource.user_id,
             hr_attendance.worked_hours   AS attendance,
             NULL::double precision       AS timesheet,
             hr_attendance.check_in::date AS date
      FROM hr_attendance
               LEFT JOIN hr_employee ON hr_employee.id = hr_attendance.employee_id
               LEFT JOIN resource_resource ON resource_resource.id = hr_employee.resource_id
      UNION ALL
      SELECT ts.id,
             ts.user_id,
             NULL::double precision AS attendance,
             ts.unit_amount         AS timesheet,
             ts.date
      FROM account_analytic_line ts
      WHERE ts.project_id IS NOT NULL) t
GROUP BY t.user_id, t.date
ORDER BY t.date;

alter table hr_timesheet_attendance_report
    owner to odoo;

