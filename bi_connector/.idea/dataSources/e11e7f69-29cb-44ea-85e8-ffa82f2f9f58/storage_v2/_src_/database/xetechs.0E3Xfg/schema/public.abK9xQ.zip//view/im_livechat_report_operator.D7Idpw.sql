create view im_livechat_report_operator
            (id, partner_id, livechat_channel_id, nbr_channel, channel_id, start_date, duration, time_to_answer) as
SELECT row_number() OVER ()                                               AS id,
       c.livechat_operator_id                                             AS partner_id,
       c.livechat_channel_id,
       count(DISTINCT c.id)                                               AS nbr_channel,
       c.id                                                               AS channel_id,
       c.create_date                                                      AS start_date,
       date_part('epoch'::text, max(m.create_date) - min(m.create_date))  AS duration,
       date_part('epoch'::text, min(mo.create_date) - min(m.create_date)) AS time_to_answer
FROM mail_channel c
         JOIN mail_message_mail_channel_rel r ON r.mail_channel_id = c.id
         JOIN mail_message m ON r.mail_message_id = m.id
         LEFT JOIN mail_message mo ON r.mail_message_id = mo.id AND mo.author_id = c.livechat_operator_id
WHERE c.livechat_channel_id IS NOT NULL
GROUP BY c.id, c.livechat_operator_id;

alter table im_livechat_report_operator
    owner to odoo;

