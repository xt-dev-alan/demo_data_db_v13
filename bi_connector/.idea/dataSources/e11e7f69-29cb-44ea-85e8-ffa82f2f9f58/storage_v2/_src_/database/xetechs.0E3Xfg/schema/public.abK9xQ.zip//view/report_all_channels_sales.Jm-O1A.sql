create view report_all_channels_sales
            (id, name, partner_id, product_id, product_tmpl_id, date_order, user_id, categ_id, company_id, price_total,
             pricelist_id, analytic_account_id, country_id, team_id, price_subtotal, product_qty)
as
SELECT foo.id,
       foo.name,
       foo.partner_id,
       foo.product_id,
       foo.product_tmpl_id,
       foo.date_order,
       foo.user_id,
       foo.categ_id,
       foo.company_id,
       foo.price_total,
       foo.pricelist_id,
       foo.analytic_account_id,
       foo.country_id,
       foo.team_id,
       foo.price_subtotal,
       foo.product_qty
FROM (SELECT sol.id,
             so.name,
             so.partner_id,
             sol.product_id,
             pro.product_tmpl_id,
             so.date_order,
             so.user_id,
             pt.categ_id,
             so.company_id,
             sol.price_total /
             CASE COALESCE(so.currency_rate, 0::numeric)
                 WHEN 0 THEN 1.0
                 ELSE so.currency_rate
                 END                                    AS price_total,
             so.pricelist_id,
             rp.country_id,
             sol.price_subtotal /
             CASE COALESCE(so.currency_rate, 0::numeric)
                 WHEN 0 THEN 1.0
                 ELSE so.currency_rate
                 END                                    AS price_subtotal,
             sol.product_uom_qty / u.factor * u2.factor AS product_qty,
             so.analytic_account_id,
             so.team_id
      FROM sale_order_line sol
               JOIN sale_order so ON sol.order_id = so.id
               LEFT JOIN product_product pro ON sol.product_id = pro.id
               JOIN res_partner rp ON so.partner_id = rp.id
               LEFT JOIN product_template pt ON pro.product_tmpl_id = pt.id
               LEFT JOIN product_pricelist pp ON so.pricelist_id = pp.id
               LEFT JOIN uom_uom u ON u.id = sol.product_uom
               LEFT JOIN uom_uom u2 ON u2.id = pt.uom_id
      WHERE so.state::text = ANY (ARRAY ['sale'::character varying::text, 'done'::character varying::text])) foo;

alter table report_all_channels_sales
    owner to odoo;

