create function unaccent(text) returns text
    immutable
    language sql
as
$$
SELECT unaccent_schema.unaccent('unaccent_schema.unaccent', $1)
$$;

alter function unaccent(text) owner to odoo;

