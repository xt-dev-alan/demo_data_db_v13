create view hr_contract_employee_report
            (id, contract_id, employee_id, company_id, departure_reason, department_id, wage, count_new_employee,
             count_employee_exit, date_start, date_end, date_end_contract, contract_start, age_sum, date,
             start_date_months, end_date_months)
as
SELECT in_query.id,
       in_query.contract_id,
       in_query.employee_id,
       in_query.company_id,
       in_query.departure_reason,
       in_query.department_id,
       in_query.wage,
       in_query.count_new_employee,
       in_query.count_employee_exit,
       in_query.date_start,
       in_query.date_end,
       in_query.date_end_contract,
       in_query.contract_start,
       in_query.age_sum,
       in_query.date,
       in_query.start_date_months,
       in_query.end_date_months
FROM (SELECT c.id,
             c.id                                                                AS contract_id,
             e.id                                                                AS employee_id,
             e.company_id,
             e.departure_reason,
             e.department_id,
             c.wage,
             CASE
                 WHEN serie.serie = start.contract_start THEN 1
                 ELSE 0
                 END                                                             AS count_new_employee,
             CASE
                 WHEN date_part('month'::text, exit.contract_end) = date_part('month'::text, serie.serie) AND
                      date_part('year'::text, exit.contract_end) = date_part('year'::text, serie.serie) THEN 1
                 ELSE 0
                 END                                                             AS count_employee_exit,
             c.date_start,
             c.date_end,
             exit.contract_end                                                   AS date_end_contract,
             start.contract_start,
             CASE
                 WHEN date_part('month'::text, c.date_start) = date_part('month'::text, serie.serie) AND
                      date_part('year'::text, c.date_start) = date_part('year'::text, serie.serie) THEN
                         (31::double precision - LEAST(date_part('day'::text, c.date_start), 30::double precision)) /
                         30::double precision
                 WHEN c.date_end IS NULL THEN 1::double precision
                 WHEN date_part('month'::text, c.date_end) = date_part('month'::text, serie.serie) AND
                      date_part('year'::text, c.date_end) = date_part('year'::text, serie.serie) THEN
                         LEAST(date_part('day'::text, c.date_end), 30::double precision) / 30::double precision
                 ELSE 1::double precision
                 END                                                             AS age_sum,
             serie.serie::date                                                   AS date,
             date_part('epoch'::text, serie.serie) / 2628028.8::double precision AS start_date_months,
             CASE
                 WHEN c.date_end IS NOT NULL AND
                      date_part('month'::text, c.date_end) = date_part('month'::text, serie.serie) AND
                      date_part('year'::text, c.date_end) = date_part('year'::text, serie.serie)
                     THEN date_part('epoch'::text, c.date_end) / 2628028.8::double precision
                 ELSE date_part('epoch'::text,
                                date_trunc('month'::text, serie.serie) + '1 mon'::interval - '1 day'::interval) /
                      2628028.8::double precision
                 END                                                             AS end_date_months
      FROM (SELECT age(COALESCE(hr_contract.date_end, CURRENT_DATE)::timestamp with time zone,
                       hr_contract.date_start::timestamp with time zone) AS age,
                   hr_contract.id,
                   hr_contract.message_main_attachment_id,
                   hr_contract.name,
                   hr_contract.active,
                   hr_contract.employee_id,
                   hr_contract.department_id,
                   hr_contract.job_id,
                   hr_contract.date_start,
                   hr_contract.date_end,
                   hr_contract.trial_date_end,
                   hr_contract.resource_calendar_id,
                   hr_contract.wage,
                   hr_contract.advantages,
                   hr_contract.notes,
                   hr_contract.state,
                   hr_contract.company_id,
                   hr_contract.kanban_state,
                   hr_contract.hr_responsible_id,
                   hr_contract.create_uid,
                   hr_contract.create_date,
                   hr_contract.write_uid,
                   hr_contract.write_date,
                   hr_contract.structure_type_id,
                   hr_contract.hourly_wage,
                   hr_contract.date_generated_from,
                   hr_contract.date_generated_to,
                   hr_contract.analytic_account_id
            FROM hr_contract
            WHERE hr_contract.state::text <> 'cancel'::text) c
               LEFT JOIN hr_employee e ON e.id = c.employee_id
               LEFT JOIN (SELECT c_end.employee_id,
                                 c_end.contract_end
                          FROM (SELECT hr_contract.employee_id,
                                       max(COALESCE(hr_contract.date_end, CURRENT_DATE)) AS contract_end
                                FROM hr_contract
                                WHERE hr_contract.state::text <> 'cancel'::text
                                GROUP BY hr_contract.employee_id) c_end
                          WHERE c_end.contract_end < CURRENT_DATE) exit ON exit.employee_id = c.employee_id
               LEFT JOIN (SELECT hr_contract.employee_id,
                                 min(hr_contract.date_start) AS contract_start
                          FROM hr_contract
                          WHERE hr_contract.state::text <> 'cancel'::text
                          GROUP BY hr_contract.employee_id) start ON start.employee_id = c.employee_id
               CROSS JOIN LATERAL generate_series(c.date_start::timestamp without time zone,
                                                  COALESCE(c.date_end::timestamp without time zone,
                                                           CURRENT_DATE + '1 year'::interval),
                                                  '1 mon'::interval) serie(serie)) in_query;

alter table hr_contract_employee_report
    owner to odoo;

